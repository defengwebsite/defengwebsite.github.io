%%**********************************************************************
%% Overload operator 'uplus/ + '
%%
%% SDPNAL+: 
%% Copyright (c) 2017 by
%% Yancheng Yuan , Kim-Chuan Toh, Defeng Sun and Xinyuan Zhao
%%**********************************************************************

function exp_obj = uplus(var_obj)
    if var_obj.block_no == -1
        error('Add the variable ''%s'' into the model first.', inputname(1));
    end
    info.exp_string = strcat('+', inputname(1));
    info.constr_dim.m = var_obj.blkorg{2};
    info.constr_dim.n = var_obj.blkorg{3};
    info.constr_type = 'symmetric';
    info.Operator_Matrix = cell(var_obj.model.info.prob.block, 1);
    matrix_temp = sqrt(2)*speye(0.5*info.constr_dim.m*(info.constr_dim.m+1));
    for i = 1:1:info.constr_dim.m
        idx = 0.5*i*(i+1);
        matrix_temp(idx, idx) = 1;
    end
    info.Operator_Matrix{var_obj.block_no} = matrix_temp;
    info.active_block = var_obj.block_no;
    info.Constant = sparse(info.constr_dim.m, info.constr_dim.n);
    info.status = 1;
    info.model = var_obj.model;
    exp_obj = expression(info);
end