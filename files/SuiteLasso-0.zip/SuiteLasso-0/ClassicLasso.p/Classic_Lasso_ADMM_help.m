%%=========================================================================
%% Classic_Lasso_ADMM: An ADMM for solving Lasso problems
%% (P) min {0.5*norm(Ax-b^2 + lambda*norm(x,1)}
%% where lambda>0. 
%%*************************************************************************
%% The ADMM is applied to the dual problem: 
%% (D) max {-0.5*norm(xi^2 + <b,xi> | AT*xi +y=0, norm(y,inf)<=lambda}
%%*************************************************************************
%% [obj,y,xi,x,info,runhist] = ...
%%      Classic_Lasso_ADMM(A,b,n,lambda,options,y0,xi0,x0)
%% (optional) y0,xi0: initial dual variables, x0: inital primal varaible
%% (optional) options: to set parameters 
%%*************************************************************************
%% All fields in the structure array "options" are optional, user can modify accordingly.
%% options.sigma      = initial penalty parameter for ADMM (default is 1)        
%% options.gamma      = stepsize between [1,1.618] (default is 1.618) 
%% options.stoptol    = stopping tolerance for relative KKT residual (default is 1e-6)
%% options.printlevel = reporting: 0,1 (default) 
%% options.maxiter    = maximum number of ADMM iterations (default is 20000)
%% options.sigmax_fix = 0,1 (fix the penalty parameter in ADMM) 
%% options.rescale    = 0,1 (default, dynamic rescaling of data) 
%% options.AATsolver  = solver for linear system with A*AT = 'cg','direct','proxLinear' (default)
%%*************************************************************************
%% SuiteLasso: 
%% Copyright (c) 2017 by
%% Xudong Li, Defeng Sun, and Kim-Chuan Toh
%%=========================================================================
