%%
  Home = pwd;
  addpath(genpath(Home));
%%
%%
  set(0,'defaultaxesfontsize',14);
  set(0,'defaultlinemarkersize',6);
  set(0,'defaulttextfontsize',14);
%%*************************************************************************
