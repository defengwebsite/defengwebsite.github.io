function [X,z,INFOS] = Pre_APGDiagMex(G,W,ConstrA,OPTIONS,c,z0)
%%%%%%%%% This code is designed to solve %%%%%%%%%%%%%
%%         min  0.5*|| W^(1/2)(X-G)W^(1/2)||^2
%%         s.t. X_ij  = e_ij     for (i,j) in (I_e,J_e)
%%              X_ij >= l_ij     for (i,j) in (I_l,J_l)
%%              X_ij <= u_ij     for (i,j) in (I_u,J_u)
%%               X >= tau0*I     X is PSD (tau0 may be zero)
%%
% Parameters:
%   Input
%   G       the given symmetric correlation matrix
%   W         the positive definite weight matrix
%   ConstrA:
%        e       the right hand side of equality constraints
%        I_e     row indices of the fixed elements
%        J_e     column indices of the fixed elements
%        l       the right hand side of lower bound constraint
%        I_l     row indices of the lower bound elements
%        J_l     column indices of the lower bound elements
%        u       the right hand side of upper bound constraint
%        I_u     row indices of the upper bound elements
%        J_u     column indices of the upper bound elements
%   OPTIONS   parameters in the OPTIONS structure
%   z0        the initial guess of dual variables
%
%   Output
%   X         the optimal primal solution
%   z:  
%      z.e    the optimal dual solution to equality constraints
%      z.l    the optimal dual solution to lower bound constraints
%      z.u    the optimal dual solution to upper bound constraints
%%%%%%%%%%%%%%%%%%%%%% Last modified on June 25, 2010. 
%%%% Line search is added!


%%
%%-----------------------------------------
%%% get constraints infos from constrA
%%-----------------------------------------
%%
e   = ConstrA.e; I_e = ConstrA.Ie; J_e = ConstrA.Je;
l   = ConstrA.l; I_l = ConstrA.Il; J_l = ConstrA.Jl;
u   = ConstrA.u; I_u = ConstrA.Iu; J_u = ConstrA.Ju;
k_e = length(e); k_l = length(l);  k_u = length(u);
k   = k_e + k_l + k_u;  n = length(G);

tau0     = 0;
tol_g    = 5.0e-1;   1.0e-1;     % termination tolerance
tol_f    = 1.0e-12;  1.0e-2;
maxit    = 200;        
maxitLS  = 20;
alpha0   = 1;   
Lip_inc  = 2;
Lip_dec  = 1.8;
opts_disp = 1;
finalEig  = 0;
const_sparse = 2;    % check if sparse form for X should be explioted
%%                                      
%%-----------------------------------------
%% get parameters from the OPTIONS structure. 
%%-----------------------------------------
%%
if exist('OPTIONS')  
    if isfield(OPTIONS,'tau0');         tau0       = OPTIONS.tau0; end
    if isfield(OPTIONS,'tol_g');        tol_g      = OPTIONS.tol_g; end
    if isfield(OPTIONS,'tol_f');        tol_f      = OPTIONS.tol_f; end
    if isfield(OPTIONS,'maxit');        maxit      = OPTIONS.maxit; end
    if isfield(OPTIONS,'disp');         opts_disp  = OPTIONS.disp; end
    if isfield(OPTIONS,'finalEig');     finalEig   = OPTIONS.finalEig; end
end
G = G - tau0*eye(n);     % reset G
G = (G +G')/2;  
Ind    = find(I_e==J_e);
e(Ind) = e(Ind) - tau0;

k1 = 0;
f_eval = 0;
eig_time = 0;

t0 = clock;


if opts_disp == 1
fprintf('\n ******************************************************** \n')
fprintf( '         Dual Accelerated Projected Gradient Algorithm                   ')
fprintf('\n ******************************************************** \n')
fprintf('\n The information of this problem is as follows: \n')
fprintf(' Dim. of    sdp      constr  = %d \n',n)
fprintf(' Num. of equality    constr  = %d \n',k_e)
fprintf(' Num. of lower bound constr  = %d \n',k_l)
fprintf(' Num. of upper bound constr  = %d \n',k_u)
fprintf(' The lower bounds: [ %2.1e, %2.1e ] \n',min(l),max(l))
fprintf(' The upper bounds: [ %2.1e, %2.1e ] \n',min(u),max(u))
end

%%% compute W^(1/2) & W^(-1/2)
% test if W is a diagonal matrix
W = real(W);
W = (W + W')/2; 
w = diag(W);
w_half  = w.^0.5;
diag_if = norm( W - diag(w), 'fro');
if diag_if < 1.0e-12    
    if min(w) <= 0
        fprintf('Warning: W is not positive definite!')
        return;
    end
else
    fprintf('Warning: W is not digaonal, but treated as diagonal!')
end

%%% reset G
for i=1:n
    G(i,:) = w_half(i)*G(i,:);
end
for j=1:n
    G(:,j) = G(:,j)*w_half(j);
end
%%% reset the constraints   
for i=1:k_e
    e(i) = e(i)*( w_half(I_e(i))*w_half(J_e(i)) );
end
for i=1:k_l
    l(i) = l(i)*( w_half(I_l(i))*w_half(J_l(i)) );
end
for i=1:k_u
    u(i) = u(i)*( w_half(I_u(i))*w_half(J_u(i)) );  %%% upper bound
end


%%% LipConst
if k_e == 0
    LipConst0 = 1;      %% sqrt(2);
else
    LipConst0 = 1;
end
% if k_e == 0
%     LipConst0 = sqrt(2)*max( 1./w_half )^4;
% else
%     LipConst0 = max( 1./w_half )^4;
% end
LipConst  = LipConst0/1;


%%% initial value of z_e,z_l,z_u
if ( nargin == 6 )
    z_e = z0.e;
    z_l = z0.l;
    z_u = z0.u;
    for i=1:k_e
        z_e(i) = z_e(i)/( w_half(I_e(i))*w_half(J_e(i)) );
    end
    for i=1:k_l
        z_l(i) = z_l(i)/( w_half(I_l(i))*w_half(J_l(i)) );
    end
    for i=1:k_u
        z_u(i) = z_u(i)/( w_half(I_u(i))*w_half(J_u(i)) );  %%% upper bound
    end
else
    z_e = zeros(k_e,1);
    z_l = zeros(k_l,1);
    z_u = zeros(k_u,1);
end


tau_old = 1;
tau_new = 1;
z_e0 = z_e; z_l0 = z_l; z_u0 = z_u;
z_e1 = z_e; z_l1 = z_l; z_u1 = z_u;
z_e = z_e1 + tau_new*(1/tau_old - 1)*(z_e1 - z_e0);
z_l = z_l1 + tau_new*(1/tau_old - 1)*(z_l1 - z_l0);
z_u = z_u1 + tau_new*(1/tau_old - 1)*(z_u1 - z_u0);
   
X = zeros(n,n);
for i=1:k_e
  X(I_e(i), J_e(i)) = z_e(i);
end
for i=1:k_l
  X(I_l(i), J_l(i)) = z_l(i) + X(I_l(i), J_l(i));
end
for i=1:k_u
  X(I_u(i), J_u(i)) = -z_u(i) + X(I_u(i), J_u(i));  %%% upper bound
end
X = 0.5*(X + X');
X = G + X;
X = (X + X')/2;
t1         = clock;
[P,lambda] = MYmexeig(X);
eig_time   = eig_time + etime(clock,t1);
%%% to compute the initial value of the merit function
[f,g_ze,g_zl,g_zu] = gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e,z_l,z_u,X,P,lambda);
f_eval = f_eval + 1;
f0 = f;

% phi = Phi(g_ze,z_l1,z_u1,g_zl,g_zu);
% if ( phi^0.5 <= tol_g )
%     fprintf('\n Initial point is good enough and preprocessing is no longer needed!')
%     z.e = z0.e; z.l = z0.l; z.u = z0.u;
%     time_used = etime(clock,t0);
%     %INFOS.primval  = prim_val;
%     INFOS.dualval  = -f;
%     INFOS.normGrad = phi^0.5;    
%     s = max(lambda,0);
%     INFOS.rankX    = length(find(s>1.0e-8));
%     INFOS.rankZ    = length(find(abs(s-lambda)>1.0e-8)); 
%     INFOS.numEig   = f_eval;
%     INFOS.eigtime  = eig_time;
%     INFOS.time     = time_used;
%     return;
% end

if opts_disp == 1
%fprintf('\n Initial dual objective function value     = %3.2e\n',-f)
time_used  = etime(clock,t0);
[hh,mm,ss] = time(time_used);
fprintf('\n Iter    StepLen    Norm of MeritFun   Dual FuncVal      Time ')
fprintf('\n  %3.0d        %s            %s             %5.4e        %d:%d:%d ',0,'-','-',-f,hh,mm,ss)
end


%%% Iteration begins  
while ( k1 <= maxit )
    
    k1 = k1+1;
    Ok = false;
    iterLS = 1;
    
    z_e0 = z_e1; z_l0 = z_l1; z_u0 = z_u1;
    
    while ( Ok == false && iterLS <= maxitLS )
        
        alpha = alpha0/LipConst;
        % update z_e,z_l,z_u
        z_e1 = z_e - alpha*g_ze;
        tmp = g_ze'*(z_e1-z_e);
        z_l1 = z_l - alpha*g_zl;
        z_l1 = max(z_l1,0);
        tmp = tmp + g_zl'*(z_l1-z_l);
        z_u1 = z_u - alpha*g_zu;
        z_u1 = max(z_u1,0);
        tmp = tmp + g_zu'*(z_u1-z_u);
        
        X = zeros(n,n);
        for i=1:k_e
            X(I_e(i), J_e(i)) = z_e1(i);
        end
        for i=1:k_l
            X(I_l(i), J_l(i)) = z_l1(i) + X(I_l(i), J_l(i));
        end
        for i=1:k_u
            X(I_u(i), J_u(i)) = -z_u1(i) + X(I_u(i), J_u(i));  %%% upper bound
        end
        X = 0.5*(X + X');
        X = G + X;
        X = (X + X')/2;
        t1         = clock;
        [P,lambda] = MYmexeig(X);
        eig_time   = eig_time + etime(clock,t1);
        [f,g_ze1,g_zl1,g_zu1] = gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e1,z_l1,z_u1,X,P,lambda);
        f_eval = f_eval + 1;
        phi    = Phi(g_ze1,z_l1,z_u1,g_zl1,g_zu1,c);
        
        %%%% check the estimation of LipConst.
        % diff = [z_e1-z_e; z_l1-z_l; z_u1-z_u];
        % Delta = 0.5*LipConst*(diff'*diff);
        % Delta = Delta + [g_ze;g_zl;g_zu]'*diff;
        diff = [z_e1-z_e; z_l1-z_l; z_u1-z_u];
        tmp = tmp + 0.5*LipConst*(diff'*diff);
        dlag = f - f0 - tmp;
        if ( dlag < 1e-8 )
            Ok = true;
        else
            LipConst = LipConst*Lip_inc;
        end
        iterLS = iterLS + 1;
        
    end
    
    if opts_disp == 1
        if ( k1 <= 50 || mod(k1,100)== 0 )
            time_used  = etime(clock,t0);
            [hh,mm,ss] = time(time_used);
            fprintf('\n %3.0d     %2.1e      %3.2e        %5.4e      %d:%d:%d ',k1,alpha,phi^0.5,-f,hh,mm,ss)
        end
    end
    
    %%% check convergence
    if ( phi^0.5 <= tol_g || sqrt( abs(f0-f)/max(1,abs(f0)) ) <= tol_f )        
        break;        
    end
    
    %%% update pars
    LipConst = LipConst/Lip_dec;
        
    tau_old = tau_new;
    %tau_new = ( 1 + sqrt(1+4*tau_old^2) )/2;
    tau_new = ( sqrt(4*tau_old^2+tau_old^4) - tau_old^2 )/2;

    z_e = z_e1 + tau_new*(1/tau_old - 1)*(z_e1 - z_e0);
    z_l = z_l1 + tau_new*(1/tau_old - 1)*(z_l1 - z_l0);
    z_u = z_u1 + tau_new*(1/tau_old - 1)*(z_u1 - z_u0);
    
    X = zeros(n,n);
    for i=1:k_e
        X(I_e(i), J_e(i)) = z_e(i);
    end
    for i=1:k_l
        X(I_l(i), J_l(i)) = z_l(i) + X(I_l(i), J_l(i));
    end
    for i=1:k_u
        X(I_u(i), J_u(i)) = -z_u(i) + X(I_u(i), J_u(i));  %%% upper bound
    end
    X = 0.5*(X + X');
    X = G + X;
    X = (X + X')/2;
    t1         = clock;
    [P0,lambda0] = MYmexeig(X);
    eig_time   = eig_time + etime(clock,t1);
    
    [f,g_ze,g_zl,g_zu] = gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e,z_l,z_u,X,P0,lambda0);
    f_eval = f_eval + 1;
    f0     = f;
       
end  % End loop for the first while


%%% info of the last iterate
if opts_disp == 1
    if ( k1 > 50 && mod(k1,100) ~= 0 )
        time_used  = etime(clock,t0);
        [hh,mm,ss] = time(time_used);
        fprintf('\n %3.0d     %2.1e      %3.2e        %5.4e      %d:%d:%d ',k1,alpha,phi^0.5,-f,hh,mm,ss)
    end
end

% to compute the optimal X*
s  = max(lambda,0);
Ip = find(s>1.0e-8);
r  = length(Ip);
if (r==0)
    X = zeros(n,n);
else
    if (r<n/2)
        s1 = s(Ip);
        s1 = s1.^0.5;
        P1 = P(:,1:r);
        P1 = P1*sparse(diag(s1));
        X = P1*P1';  % Optimal solution X*
    else
        In = find(s~=lambda);
        r2 = length(In);
        if r2>0               %%if r2 =0, then X=X;
            s2 = s(In)-lambda(In);
            s2 = s2.^0.5;
            P2 = P(:,n-r2+1:n);
            P2 = P2*sparse(diag(s2));
            X = X + P2*P2';  % Optimal solution X*
        end
    end
end
X = (X+X')/2;
%%% the rank of optimal X* and Z*
r_X = r;              
r_Z = length(find(abs(s-lambda)>1.0e-8));  
%%% optimal primal value
prim_val = sum(sum((X-G).*(X-G)))/2;


%%% recover dual solution
for i=1:k_e
    z_e(i) = z_e1(i)*( w_half(I_e(i))*w_half(J_e(i)) );
end
for i=1:k_l
    z_l(i) = z_l1(i)*( w_half(I_l(i))*w_half(J_l(i)) );
end
for i=1:k_u
    z_u(i) = z_u1(i)*( w_half(I_u(i))*w_half(J_u(i)) );  %%% upper bound
end
z.e = z_e; z.l = z_l; z.u = z_u;
%%%%%%%%%%%%%%%%%%%%%%

%%% recover X* to the original one
for i=1:n
    X(i,:) = X(i,:)/w_half(i);
end
for j=1:n
    X(:,j) = X(:,j)/w_half(j);
end
X = X + tau0*eye(n);

%%% compute P and lambda of the X
if ( max(w)/min(w) - 1 <= 1.0e-12 )  % W=scalar*I
    lambda = s./max(w);
    INFOS.P     = P;
    INFOS.lam   = lambda;
    INFOS.rank  = r_X;
else
    if finalEig        
        t1         = clock;
        [P,lambda] = MYmexeig(X);
        eig_time   = eig_time + etime(clock,t1);        
        INFOS.P     = P;
        INFOS.lam   = lambda;
        INFOS.rank  = r_X;
    end
end

time_used = etime(clock,t0);
%INFOS.primval  = prim_val;
INFOS.dualval  = -f;
INFOS.normGrad = phi^0.5;
INFOS.rankX    = r_X;
INFOS.rankZ    = r_Z;
INFOS.numEig   = f_eval;
INFOS.eigtime  = eig_time;
INFOS.time     = time_used;

if opts_disp == 1
    fprintf('\n')
    fprintf('\n ================ Final Information ================= \n');
    fprintf(' Total number of iterations      = %2.0f \n',k1);
    fprintf(' Number of func. evaluations     = %2.0f \n',f_eval)
    fprintf(' Primal objective value          = %d \n', prim_val)
    fprintf(' Dual objective value            = %d \n',-f)
    fprintf(' Norm of the KKT function        = %3.2e \n', phi^0.5)
    fprintf(' Rank of  X*-(tau*I)             == %2.0d \n', r_X);
    fprintf(' Rank of optimal multiplier Z*   == %2.0d \n', r_Z);
    fprintf(' Computing time for eigen-decom  === %3.1f \n',eig_time)
    fprintf(' Total computing time (secs)     === %3.1f \n',time_used)
    fprintf(' ====================================================== \n');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% end of maim program %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%







%%  **************************************
%%  ******** All Sub-routines  ***********
%%  **************************************
%%% To change the format of time 
function [h,m,s] = time(t)
t = round(t); 
h = floor(t/3600);
m = floor(rem(t,3600)/60);
s = rem(rem(t,60),60);
%%% End of time.m 



%%% mexeig decomposition
function [P,lambda] = MYmexeig(X)
[P,lambda] = mexeig(X);
P          = real(P);
lambda     = real(lambda);
if issorted(lambda)
    lambda = lambda(end:-1:1);
    P      = P(:,end:-1:1);
elseif issorted(lambda(end:-1:1))
    return;
else
    [lambda, Inx] = sort(lambda,'descend');
    P = P(:,Inx);
end
return
%%% End of MYmexeig.m





%%% To generate merit function phi 
function  phi = Phi(g_ze,z_l,z_u,g_zl,g_zu,c)
k_e = length(g_ze);  
k_l = length(g_zl);  
k_u = length(g_zu);
k   = k_e + k_l + k_u;

g_ze = c(1:k_e).*g_ze;
g_zl = c(k_e+1:k_e+k_l).*g_zl;
g_zl = z_l - max(z_l-g_zl, 0);
g_zu = c(k_e+k_l+1:k).*g_zu;
g_zu = z_u - max(z_u-g_zu, 0);

phi = norm(g_ze)^2 + norm(g_zl)^2 + norm(g_zu)^2;
return
%%% End of Phi.m 



%%% To generate the gradient of dual objective function
function [f,g_ze,g_zl,g_zu] = ...
    gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e,z_l,z_u,X,P,lambda)

n   = length(G);
k_e = length(e);
k_l = length(l);
k_u = length(u);
k   = k_e + k_l + k_u;

g_ze = zeros(k_e,1);
g_zl = zeros(k_l,1);
g_zu = zeros(k_u,1);

% to generate SDP projection
s  = max(lambda,0);
Ip = find(s>0);
r  = length(Ip);

const_sparse = 2;  %sparsity parameter
if (r>0)
    if (r==n)
        i=1;
        while (i<=k_e)
            g_ze(i) = X(I_e(i),J_e(i));
            i=i+1;
        end
        i=1;
        while (i<=k_l)
            g_zl(i) = X(I_l(i),J_l(i));
            i=i+1;
        end
        i=1;
        while (i<=k_u)
            g_zu(i) = -X(I_u(i),J_u(i));
            i=i+1;
        end
    else %0<r<n
        if k <= const_sparse*n  % sparse form
            if (r<n/2)
                s1 = s(Ip);
                P1 = P(:,1:r);
                
                M = P1';
                i=1;
                while (i<=r)
                    M(i,:) = s1(i)*M(i,:);
                    i = i+1;
                end

                i=1;
                while (i<=k_e)
                    g_ze(i) = P1(I_e(i),:)*M(:,J_e(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_l)
                    g_zl(i) = P1(I_l(i),:)*M(:,J_l(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_u)
                    g_zu(i) = -P1(I_u(i),:)*M(:,J_u(i));
                    i=i+1;
                end
            else %(r>=n/2)
                s2 = -lambda(r+1:n);
                P2 = P(:,r+1:n);
                
                M = P2';
                i=1;
                while (i<=n-r)
                    M(i,:) = s2(i)*M(i,:);
                    i = i+1;
                end
                
                i=1;
                while (i<=k_e)
                    g_ze(i) = X(I_e(i),J_e(i)) + P2(I_e(i),:)*M(:,J_e(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_l)
                    g_zl(i) = X(I_l(i),J_l(i)) + P2(I_l(i),:)*M(:,J_l(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_u)
                    g_zu(i) = -( X(I_u(i),J_u(i)) + P2(I_u(i),:)*M(:,J_u(i)) );
                    i=i+1;
                end                
            end
            
        else %dense form
            if (r<n/2)
                s1 = s(Ip);
                s1 = s1.^0.5;
                P1 = P(:,Ip);
                P1 = P1*sparse(diag(s1));
                M  = P1*P1';
            else
                s2 = -lambda(r+1:n);
                s2 = s2.^0.5;
                P2 = P(:,r+1:n);
                P2 = P2*sparse(diag(s2));
                M  = X + P2*P2';
            end

            i=1;
            while (i<=k_e)
                g_ze(i) = M(I_e(i),J_e(i));
                i=i+1;
            end
            i=1;
            while (i<=k_l)
                g_zl(i) = M(I_l(i),J_l(i));
                i=i+1;
            end
            i=1;
            while (i<=k_u)
                g_zu(i) = -M(I_u(i),J_u(i));
                i=i+1;
            end
        end
    end
end
g_ze = g_ze - e;
g_zl = g_zl - l;
g_zu = g_zu + u;

f = s'*s;
f = 0.5*f - sum(sum(G.*G))/2 - z_e'*e - z_l'*l + z_u'*u;

return
%%% End of gradient.m 






