function [X,z] = Pre_ProjGradMex(G,W,ConstrA,OPTIONS,z0)
%%%%%%%%% This code is designed to solve %%%%%%%%%%%%%
%%         min  0.5*|| W^(1/2)(X-G)W^(1/2)||^2
%%         s.t. X_ij  = e_ij     for (i,j) in (I_e,J_e)
%%              X_ij >= l_ij     for (i,j) in (I_l,J_l)
%%              X_ij <= u_ij     for (i,j) in (I_u,J_u)
%%                 X >= tau*I   X is PSD (tau0 may be zero)
%%
% Parameters:
%   Input
%   G       the given symmetric correlation matrix
%   W         the positive definite weight matrix
%   ConstrA:
%        e       the right hand side of equality constraints
%        I_e     row indices of the fixed elements
%        J_e     column indices of the fixed elements
%        l       the right hand side of lower bound constraint
%        I_l     row indices of the lower bound elements
%        J_l     column indices of the lower bound elements
%        u       the right hand side of upper bound constraint
%        I_u     row indices of the upper bound elements
%        J_u     column indices of the upper bound elements
%   OPTIONS   parameters in the OPTIONS structure
%   z0        the initial guess of dual variables
%
%   Output
%   X         the optimal primal solution
%   z:  
%      z.e    the optimal dual solution to equality constraints
%      z.l    the optimal dual solution to lower bound constraints
%      z.u    the optimal dual solution to upper bound constraints
%%%%%% Last modified on March 28, 2010. 


%%
%%-----------------------------------------
%%% get constraints infos from constrA
%%-----------------------------------------
%%
e   = ConstrA.e; I_e = ConstrA.Ie; J_e = ConstrA.Je;
l   = ConstrA.l; I_l = ConstrA.Il; J_l = ConstrA.Jl;
u   = ConstrA.u; I_u = ConstrA.Iu; J_u = ConstrA.Ju;
k_e = length(e); k_l = length(l);  k_u = length(u);
k   = k_e + k_l + k_u;  n = length(G);

tau   = 0;
tol   = 1.0e-1;    % termination tolerance
maxit = 200;
alpha0   = 1.8;
maxitLS  = 40;       % maximum number of line search
mu       = 1.0e-4;   % parameter used in the line search
const_sparse = 2;    % check if sparse form for X should be explioted
%%                                      
%%-----------------------------------------
%% get parameters from the OPTIONS structure. 
%%-----------------------------------------
%%
if exist('OPTIONS')  
    if isfield(OPTIONS,'tau');          tau      = OPTIONS.tau; end
    if isfield(OPTIONS,'tol');          tol      = OPTIONS.tol; end
    if isfield(OPTIONS,'maxit');        maxit    = OPTIONS.maxit; end
end
G = G - tau*eye(n);     % reset G
G = (G+G')/2;  
Ind    = find(I_e==J_e);
e(Ind) = e(Ind) - tau;

k1 = 0;
f_eval = 0;
eig_time = 0;

t0 = clock;

fprintf('\n ******************************************************** \n')
fprintf( '         Dual Projected Gradient Algorithm                   ')
fprintf('\n ******************************************************** \n')
fprintf('\n The information of this problem is as follows: \n')
fprintf(' Dim. of    sdp      constr  = %d \n',n)
fprintf(' Num. of equality    constr  = %d \n',k_e)
fprintf(' Num. of lower bound constr  = %d \n',k_l)
fprintf(' Num. of upper bound constr  = %d \n',k_u)
fprintf(' The lower bounds: [ %2.1e, %2.1e ] \n',min(l),max(l))
fprintf(' The upper bounds: [ %2.1e, %2.1e ] \n',min(u),max(u))


%%% compute W^(1/2) & W^(-1/2)
% test if W is a diagonal matrix
W = real(W);
W = (W + W')/2; 
w = ones(n,1);
diag_if = norm( W - diag(diag(W)), 'fro');
if diag_if < 1.0e-12
    diag_index = 1;
    w = diag(W);
    if min(w) <= 0
        fprintf('Warning: W is not positive definite!')
        return;
    end
else
    diag_index = 0;
end

if diag_index == 0   % not a diagonal weight matrix
    t1         = clock;
    [P,lambda] = MYmexeig(W);
    eig_time   = eig_time + etime(clock,t1);
    if min(lambda) <= 0
        fprintf('Warning: W is not positive definite!')
        return;
    end
    tmp    = real(lambda.^(1/4));
    W_half = P*sparse(diag(tmp));
    W_half = W_half * W_half';

    tmp        = real(lambda.^(-1/4));
    W_half_inv = P*sparse(diag(tmp));
    W_half_inv = W_half_inv * W_half_inv';
    
    %%% reset G
    G = W_half*G*W_half;

    LipConst = 1;     %% initial estimation
    %%% 
%     if k_e == 0
%         LipConst = sqrt(2)*max( 1./(lambda.^0.5) )^4;
%     else
%         LipConst = max( 1./(lambda.^0.5) )^4;
%     end
    
    
else
    w_half = w.^0.5;
    
    %%% reset G
    for i=1:n
        G(i,:) = w_half(i)*G(i,:);
    end
    for j=1:n
        G(:,j) = G(:,j)*w_half(j);
    end
    
    LipConst = 1;   %% initial estimation
    %%% 
%     if k_e == 0
%         LipConst = sqrt(2)*max( 1./w_half )^4;
%     else
%         LipConst = max( 1./w_half )^4;
%     end
    
    
end


%%% initial value of z_e,z_l,z_u
if ( nargin == 5 )
    z_e = z0.e;
    z_l = z0.l;
    z_u = z0.u;
else
    z_e = zeros(k_e,1);
    z_l = zeros(k_l,1);
    z_u = zeros(k_u,1);
end
x0_ze = z_e;
x0_zl = z_l;
x0_zu = z_u;

X = zeros(n,n);
for i=1:k_e
  X(I_e(i), J_e(i)) = z_e(i);
end
for i=1:k_l
  X(I_l(i), J_l(i)) = z_l(i) + X(I_l(i), J_l(i));
end
for i=1:k_u
  X(I_u(i), J_u(i)) = -z_u(i) + X(I_u(i), J_u(i));  %%% upper bound
end
X = 0.5*(X + X');
if diag_index == 0
    if k <= const_sparse*n
        X = W_half_inv*sparse(X);
        X = X*W_half_inv;
    else
        X = W_half_inv*X*W_half_inv;
    end
else
    for i=1:n
        X(i,:) = X(i,:)/w_half(i);
    end
    for j=1:n
        X(:,j) = X(:,j)/w_half(j);
    end
end
X = G + X;
X = (X + X')/2;
t1         = clock;
[P,lambda] = MYmexeig(X);
eig_time   = eig_time + etime(clock,t1);
if diag_index == 0
    WP = W_half_inv*P;
else
    WP = P;
    for i=1:n
        WP(i,:) = P(i,:)/w_half(i);
    end
end


%%% to compute the gradient
if diag_index == 0
    WXW = W_half_inv*X*W_half_inv;
else
    WXW = X;
    for i=1:n
        WXW(i,:) = WXW(i,:)/w_half(i);
    end
    for j=1:n
        WXW(:,j) = WXW(:,j)/w_half(j);
    end    
end
[f,g_ze,g_zl,g_zu] = gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e,z_l,z_u,WXW,WP,lambda);
f_eval = f_eval + 1;
f0     = f;

%%% to compute the initial value of the merit function
phi = Phi(g_ze,z_l,z_u,g_zl,g_zu);
fprintf('\n Initial norm of merit function            = %3.2e',phi^0.5)
fprintf('\n Initial dual objective function value     = %3.2e\n',-f)

time_used  = etime(clock,t0);
[hh,mm,ss] = time(time_used);
fprintf('\n Iter.     Step length       Norm of merit fun.   FuncVal    time_used')
fprintf('\n  %d         %s                    %3.2e          %3.2e        %d:%d:%d ',0,'-',phi^0.5,-f,hh,mm,ss)

alpha = alpha0/LipConst;
%%% Iteration begins
while ( phi^0.5 > tol && k1 < maxit)
     
     k1 = k1+1;
     t  = 0;
     Ok = false;     
            
     g_ze0 = g_ze;
     g_zl0 = g_zl;
     g_zu0 = g_zu;
     
     while ( Ok==false && t < maxitLS )

         % update z_e,z_l,z_u
         z_e = x0_ze - alpha*g_ze0;
         tmp = alpha*g_ze0'*(-g_ze0);
         z_l = x0_zl - alpha*g_zl0;
         z_l = max(z_l,0);
         tmp = tmp + g_zl0'*(z_l-x0_zl);
         z_u = x0_zu - alpha*g_zu0;
         z_u = max(z_u,0);
         tmp = tmp + g_zu0'*(z_u-x0_zu);

         X = zeros(n,n);
         for i=1:k_e
             X(I_e(i), J_e(i)) = z_e(i);
         end
         for i=1:k_l
             X(I_l(i), J_l(i)) = z_l(i) + X(I_l(i), J_l(i));
         end
         for i=1:k_u
             X(I_u(i), J_u(i)) = -z_u(i) + X(I_u(i), J_u(i));  %%% upper bound
         end
         X = 0.5*(X + X');        
         if diag_index == 0
             if k <= const_sparse*n
                 X = W_half_inv*sparse(X);
                 X = X*W_half_inv;
             else
                 X = W_half_inv*X*W_half_inv;
             end
         else
             for i=1:n
                 X(i,:) =  X(i,:)/w_half(i);
             end
             for j=1:n
                 X(:,j) =  X(:,j)/w_half(j);
             end
         end
         X = G + X;
         X = (X + X')/2;
         t1         = clock;
         [P,lambda] = MYmexeig(X);
         eig_time   = eig_time + etime(clock,t1);
         if diag_index == 0
             WP = W_half_inv*P;
         else
             WP = P;
             for i=1:n
                 WP(i,:) = P(i,:)/w_half(i);
             end
         end

         if diag_index == 0
             WXW = W_half_inv*X*W_half_inv;
         else
             WXW = X;
             for i=1:n
                 WXW(i,:) = WXW(i,:)/w_half(i);
             end
             for j=1:n
                 WXW(:,j) = WXW(:,j)/w_half(j);
             end
         end
         [f,g_ze,g_zl,g_zu] = gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e,z_l,z_u,WXW,WP,lambda);
         f_eval = f_eval + 1;
         tmp1 = mu*tmp;
         dlag = f - f0 - tmp1;

         if ( dlag < 1e-8 )
             Ok = true;
         else
             alpha = alpha/2;
         end
         t = t+1;
         
     end    % End loop for line search

        f0    = f;
        x0_ze = z_e;
        x0_zl = z_l;
        x0_zu = z_u;
                
        phi = Phi(g_ze,z_l,z_u,g_zl,g_zu);
        
        if ( k1 <= 20 || mod(k1,100) == 0 )
            time_used  = etime(clock,t0);
            [hh,mm,ss] = time(time_used);
            fprintf('\n %2.0d         %2.1e            %3.2e        %3.2e          %d:%d:%d ', k1,alpha/1.8,phi^0.5,-f,hh,mm,ss)
        end
        
        alpha = 1.8*alpha;
        
end  % End loop for the first while

% %%% info of the last iterate
% if ( k1 > 20 && mod(k1,100) ~= 0 )
% time_used  = etime(clock,t0);
% [hh,mm,ss] = time(time_used);
% fprintf('\n %2.0d         %2.1e            %3.2e         %3.2e          %d:%d:%d ', k1,alpha,phi^0.5,-f,hh,mm,ss)
% end

% to compute the optimal X*
s  = max(lambda,0);
Ip = find(s>0);
r  = length(Ip);
if (r==0)
    X = zeros(n,n);
else
    if (r<n/2)
        s1 = s(Ip);
        s1 = s1.^0.5;
        P1 = P(:,1:r);
        P1 = P1*sparse(diag(s1));
        X = P1*P1';  % Optimal solution X*
    else
        In = find(s~=lambda);
        r2 = length(In);
        if r2>0               %%if r2 =0, then X=X;
            s2 = s(In)-lambda(In);
            s2 = s2.^0.5;
            P2 = P(:,n-r2+1:n);
            P2 = P2*sparse(diag(s2));
            
            X = X + P2*P2';  % Optimal solution X*
        end
    end
end
X = (X+X')/2;

%%% the rank of optimal X* and Z*
r_X = r;              
r_Z = length(find(abs(s-lambda)>1.0e-18));  

%%% optimal primal value
prim_val = sum(sum((X-G).*(X-G)))/2;

%%% recover X* to the original one
if diag_index == 0    
    X = W_half_inv*X*W_half_inv;    
else
    for i=1:n
        X(i,:) = X(i,:)/w_half(i);
    end
    for j=1:n
        X(:,j) = X(:,j)/w_half(j);
    end
end
X = X + tau*speye(n);

z.e = z_e;
z.l = z_l;
z.u = z_u;
%%%%%%%%%%%%%%%%%%%%%%

time_used = etime(clock,t0);

fprintf('\n')
fprintf('\n ================ Final Information ================= \n');
fprintf(' Total number of iterations      = %2.0f \n',k1);
fprintf(' Number of func. evaluations     = %2.0f \n',f_eval)
fprintf(' Primal objective value          = %d \n', prim_val)
fprintf(' Dual objective value            = %d \n',-f)
fprintf(' Norm of the KKT function        = %3.2e \n', phi^0.5)
fprintf(' Rank of  X*-(tau*I)             == %2.0d \n', r_X);
fprintf(' Rank of optimal multiplier Z*   == %2.0d \n', r_Z);
fprintf(' Computing time for eigen-decom  === %3.1f \n',eig_time)
fprintf(' Total computing time (secs)     === %3.1f \n',time_used)
fprintf(' ====================================================== \n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% end of maim program %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%







%%  **************************************
%%  ******** All Sub-routines  ***********
%%  **************************************
%%% To change the format of time 
function [h,m,s] = time(t)
t = round(t); 
h = floor(t/3600);
m = floor(rem(t,3600)/60);
s = rem(rem(t,60),60);
%%% End of time.m 




%%% mexeig decomposition
function [P,lambda] = MYmexeig(X)
[P,lambda] = mexeig(X);
P          = real(P);
lambda     = real(lambda);
if issorted(lambda)
    lambda = lambda(end:-1:1);
    P      = P(:,end:-1:1);
elseif issorted(lambda(end:-1:1))
    return;
else
    [lambda, Inx] = sort(lambda,'descend');
    P = P(:,Inx);
end
return
%%% End of MYmexeig.m




%%% To generate merit function phi 
function  phi = Phi(g_ze,z_l,z_u,g_zl,g_zu)
g_zl = z_l - max(z_l-g_zl, 0);
g_zu = z_u - max(z_u-g_zu, 0);
 
phi = norm(g_ze)^2 + norm(g_zl)^2 + norm(g_zu)^2;
return
%%% End of Phi.m 





%%% To generate the gradient of dual objective function
function [f,g_ze,g_zl,g_zu] = ...
    gradient(G,e,I_e,J_e,l,I_l,J_l,u,I_u,J_u,z_e,z_l,z_u,X,P,lambda)

n   = length(G);
k_e = length(e);
k_l = length(l);
k_u = length(u);
k   = k_e + k_l + k_u;

g_ze = zeros(k_e,1);
g_zl = zeros(k_l,1);
g_zu = zeros(k_u,1);

% to generate SDP projection
s  = max(lambda,0);
Ip = find(s>0);
r  = length(Ip);

const_sparse = 2;  %sparsity parameter
if (r>0)
    if (r==n)
        i=1;
        while (i<=k_e)
            g_ze(i) = X(I_e(i),J_e(i));
            i=i+1;
        end
        i=1;
        while (i<=k_l)
            g_zl(i) = X(I_l(i),J_l(i));
            i=i+1;
        end
        i=1;
        while (i<=k_u)
            g_zu(i) = -X(I_u(i),J_u(i));
            i=i+1;
        end
    else %0<r<n
        if k<=const_sparse*n  %sparse form
            if (r<n/2)
                s1 = s(Ip);
                P1 = P(:,1:r);
                
                M = P1';
                i=1;
                while (i<=r)
                    M(i,:) = s1(i)*M(i,:);
                    i = i+1;
                end

                i=1;
                while (i<=k_e)
                    g_ze(i) = P1(I_e(i),:)*M(:,J_e(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_l)
                    g_zl(i) = P1(I_l(i),:)*M(:,J_l(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_u)
                    g_zu(i) = -P1(I_u(i),:)*M(:,J_u(i));
                    i=i+1;
                end
            else %(r>=n/2)
                s2 = -lambda(r+1:n);
                P2 = P(:,r+1:n);
                
                M = P2';
                i=1;
                while (i<=n-r)
                    M(i,:) = s2(i)*M(i,:);
                    i = i+1;
                end
                
                i=1;
                while (i<=k_e)
                    g_ze(i) = X(I_e(i),J_e(i)) + P2(I_e(i),:)*M(:,J_e(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_l)
                    g_zl(i) = X(I_l(i),J_l(i)) + P2(I_l(i),:)*M(:,J_l(i));
                    i=i+1;
                end
                i=1;
                while (i<=k_u)
                    g_zu(i) = -( X(I_u(i),J_u(i)) + P2(I_u(i),:)*M(:,J_u(i)) );
                    i=i+1;
                end                
            end
            
        else %dense form
            if (r<n/2)
                s1 = s(Ip);
                s1 = s1.^0.5;
                P1 = P(:,Ip);
                P1 = P1*sparse(diag(s1));
                M  = P1*P1';
            else
                s2 = -lambda(r+1:n);
                s2 = s2.^0.5;
                P2 = P(:,r+1:n);
                P2 = P2*sparse(diag(s2));
                M  = X + P2*P2';
            end

            i=1;
            while (i<=k_e)
                g_ze(i) = M(I_e(i),J_e(i));
                i=i+1;
            end
            i=1;
            while (i<=k_l)
                g_zl(i) = M(I_l(i),J_l(i));
                i=i+1;
            end
            i=1;
            while (i<=k_u)
                g_zu(i) = -M(I_u(i),J_u(i));
                i=i+1;
            end
        end
    end
end
g_ze = g_ze-e;
g_zl = g_zl-l;
g_zu = g_zu+u;

f = s'*s;
f = 0.5*f - sum(sum(G.*G))/2 - z_e'*e - z_l'*l + z_u'*u;
return
%%% End of gradient.m 







