clear all




n = 500;
%%
%%-----------------------------------------
%%% Generate matrix G
%%-----------------------------------------
%%
LongCorr = 0.5; 
beta     = -0.05;
G = zeros(n,n);
for i = 1:n
    for j = 1:i        
        G(i,j) = LongCorr + (1-LongCorr)*exp(beta*abs(i-j));        
    end
end
G = G + G' - diag(diag(G));


%%% The rank constraint
r_rank = 20;




 
gradtol   = 1.0e-5;  
ftest     = 0;
ftol      = 1.0e-6;
tolrel    = 1.0e-5; 
% fprintf('\n---------- Call Major weight ---------------')
 [Xn, Fn] = major_original( G, r_rank, ftol, ftest, gradtol, tolrel);
 

 [Xn, Fn] = major( G, r_rank, ftol, ftest, gradtol, tolrel );

 



