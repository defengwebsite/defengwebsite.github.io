function [Xn, Fn, residue_1, time] = major_test( R, d, ftol, ftest, gradtol, tolrel )
%  MAJOR Majorisation algorithm for rank reduction of correlation matrices
%  Majorization algorithm for minimization of F(X)=norm(R-X*X','fro')^2 such that diag(X*X')=I with X an nxd matrix with n=size(R,1)=size(R,2). Convergence is
%  guaranteed if the matrix R is symmetric and has unit diagonal. Tolerance is the convergence criterion for the
%  norm of the gradient 4*Psi*X with Psi = Y*Y'-R.
%  usage [Xn, Fn] = major( R, d, tol )

%%% Last modified on November 23, 2009;  10:00AM

   t0 = clock;
    
   
   residue_cutoff = 1;
   if tolrel <= 1.0e-4;
       residue_cutoff = 10;
   end

   const1_disp = 10;
   const2_disp = 10;
   const_hist = 20000;
   hist_residue = zeros(const_hist,1);
   n_base = 5;
   
   eigdecomp_time = 0; 
   disp_level = 1;
   
   
   
   % first obtain initial guess
   X = mGuess(R,d);
    
    % initial gradient, obj value
    mygrad = grad( X, R );
    normgrad = norm(mygrad,'fro');
    Fn = F(X,R);
    
    residue_1 = sqrt(Fn);
    hist_residue(1) = residue_1;
    
    
    
    Fold = 1.0e16; % at first iteration no Fold is known, this choice guarantees that convergence is not obtained at the first iteration
    

    
    % output
    iter = 0;
    fprintf('\n')
    disp(sprintf('%s\t%s\t\t%s\t\t%s\t\t%s','iter','|grad|','F(X)','Time','maximum_eig_time'));    
    time = etime(clock,t0);
    disp(sprintf('%d\t%3.2e\t%9.8e\t%.1f\t\t\t\t\t%.1f',iter,normgrad,sqrt(Fn),time,eigdecomp_time));
    
    % dimension
    N = size(R,1);
   
    
    
   
    
    %while normgrad>tol
    %while (  normgrad>gradtol && (Fold^0.5-Fn^0.5)/max(1,Fold^0.5) > ftol )
     %while (  normgrad > gradtol && abs(Fn^0.5 - ftest)/max(1,ftest) > ftol )
  while ( normgrad > gradtol )
     
     
        for i=1:N

            % calculate B and its largest eigenvalue lambda
            B = X'*X - X(i,:)'*X(i,:);
          
            tt = clock;
            if d <= 125
                lambda = max(eig(B));
            else
                OPTS.disp = 0;
                lambda = eigs(B,1,'LA',OPTS);
            end
            eigdecomp_time  = eigdecomp_time  + etime(clock,tt);
           
           
           z = (lambda-1.0)*X(i,:) - (B*X(i,:)')' + R(i,:)*X;
           X(i,:) = z/norm(z);
        
        end
        
        % gradient, obj value
        iter = iter+1;
 
        mygrad = grad( X, R );
        normgrad = norm(mygrad,'fro');
        
        Fn = F(X,R);        
        residue_1 = sqrt(Fn);
        hist_residue(iter+1)= residue_1;
        
         
        % output
        if ( iter <=  const1_disp || mod(iter,const2_disp) == 0 )
            disp_level = 1;
            time = etime(clock,t0);
            disp(sprintf('%d\t%3.2e\t%9.8e\t%.1f\t\t\t\t\t%.1f',iter,normgrad,sqrt(Fn),time,eigdecomp_time));
        else
            disp_level = 0;
        end
        
        %%% termination test
        if  iter >= n_base-1
            relErr = abs( hist_residue(iter+2-n_base) - hist_residue(iter+1))...
                / max( residue_cutoff , max(hist_residue(iter+1), hist_residue(iter+2-n_base)));
            if relErr <= tolrel
                if disp_level == 0
                   disp(sprintf('%d\t%3.2e\t%9.8e\t%.1f\t\t\t\t\t%.1f',iter,normgrad,sqrt(Fn),time,eigdecomp_time));
                   disp_level = 1;
                end
                fprintf(' relative error = %8.7e \n',relErr)
                break;
            end
        end
        
        
  end
   
Xn = X;

if disp_level == 0
time  = etime(clock,t0);
%ttime = time;
disp(sprintf('%d\t%3.2e\t%9.8e\t%.1f\t\t\t\t\t%.1f',iter,normgrad,sqrt(Fn),time,eigdecomp_time));
end

return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% end of the main program %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%  **************************************
%%  ******** All Sub-routines  ***********
%%  **************************************
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% mexeig decomposition
function [P,lambda] = MYmexeig(X)
[P,lambda] = mexeig(X);
P          = real(P);
lambda     = real(lambda);
if issorted(lambda)
    lambda = lambda(end:-1:1);
    P      = P(:,end:-1:1);
elseif issorted(lambda(end:-1:1))
    return;
else
    [lambda, Inx] = sort(lambda,'descend');
    P = P(:,Inx);
end
% % % Rearrange lambda and P in the nonincreasing order
% % if lambda(1) < lambda(end) 
% %     lambda = lambda(end:-1:1);
% %     P      = P(:,end:-1:1);
% % end
return
%%% End of MYmexeig.m




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function nY = clamp(Y)
% CLAMP rescales the n row vectors of the matrix Y to unit length. If a row vector a priori has length zero, a
% random choice is made.
%
%	Usages:
%	nY = CLAMP(Y)
%
%	Y is expected to satisfy diag(Y*Y')=I to order epsilon
%	nY will satisfy Y'*Y = I
%
[n,d] = size(Y);
% set correct dimensions
nY = Y;
for i=1:n
    normY=norm( Y(i,:), 'fro' );
    if normY > 0.0
        nY(i,:) = Y(i,:) / normY;
    else
        nY(i,:) = zeros(1,d); nY(i,1)=1.0;
    end
end
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Y = mGuess(C, d, varargin)
%guess Y=guess(C,d)
% usages:
%   Y=guess(C,d)
%   Y=guess(C,d,W)
% Finds an initial feasible point Y to the problem min norm(R-X*X','fro')^2 subject to diag(X*X')=I with X an nxd
% matrix, n=size(C,1).
% If W is provided the factorisation is performed with respect to the matrix norm induced by the positive semidefinite matrix W
% the 'default' for W is I

% dim
n = size(C,1);

% is a weights matrix provided?
if length( varargin ) == 1
    W = varargin{1};
else
    W = eye(n);
end

% square root of W
[P,lambda] = MYmexeig(W);
lambda = max(0,lambda).^0.25;
sqrW = W;
isqrW = W;
for i=1:n
    sqrW(i,:)  = lambda(i)* P(i,:);
    isqrW(i,:) = P(i,:)/lambda(i);
end
sqrW = sqrW * sqrW';
isqrW =  isqrW * isqrW';

% project onto rank d
[V,dd] = MYmexeig( sqrW*C*sqrW );
%[V,dd] = svdplus( sqrW*C*sqrW );
dd = max(dd, 0);
dd = dd.^0.5;
Y  =  isqrW*( V(:,1:d)  * sparse(diag(dd(1:d))));

% rescale Y
Y = clamp( Y );
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ f ] = F( X, R )
%F F(X,R)=norm(R-X*X','fro')^2
%  F(X,R)=norm(R-X*X','fro')^2

f = norm(R-X*X','fro')^2;
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result = dF( Y, C )
% result = dF( Y )
% the differential of F
Psi = Y*Y'-C;
result = 4*Psi*Y;
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function G = grad(Y,C)
% GRAD	computes the gradient of the function F at the point Y.
%	G = GRAD(Y)
%	Y is expected to satisfy diag(Y*Y')=I.
%	G will satisfy G = P_tangent(Y,dF(Y,C))
G = P_tangent(Y,dF(Y,C));
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Delta = P_tangent( Y, X )
% Delta = P_tangent( Y, X )
% projects X onto the tangent space at Y thereby producing Delta
% The manifold here is { Y nxd real matrix, norm(Y(i,:))=1 i=1:n } (n
% products of the d-1 sphere)
Delta = X - diag( diag( X * Y' ) ) * Y;
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 