function [X,P,lambda,rank_X,rankErr,normInf,infoNum] = IntPoint_lub(G,ConstrA,Rank,X,P,lambda,opt_disp)
%%%  Last modified on June 25, 2010.

%%
%%-----------------------------------------
%%% get constraints infos from constrA
%%-----------------------------------------
%%
e   = ConstrA.e; I_e = ConstrA.Ie; J_e = ConstrA.Je;
l   = ConstrA.l; I_l = ConstrA.Il; J_l = ConstrA.Jl;
u   = ConstrA.u; I_u = ConstrA.Iu; J_u = ConstrA.Ju;
k_e = length(e); k_l = length(l);  k_u = length(u);
k   = k_e + k_l + k_u;  n = length(G);
%%% reset input pars  
G   = (G + G')/2;        
Ind = find(I_e==J_e);
e_diag = e(Ind);

%%% set parameters
%tolrel   = 1.0e-8;   
tolinf    = 1.0e-6;
%tolrank  = 1.0e-8; %% no need to change
rankErr_stop = 1.0e-1;
maxit    = 5; 
maxitsub = 2;
eps_step    = 1.0e-2;
eps_bar_min = 1.0e-4;
const.disp1 = 20;
const.disp2 = 10;
infoNum.callCN      = 0;
infoNum.iterCN      = 0;
infoNum.JacobProd   = 0;
infoNum.eigendecom  = 0;
%%% penalty par  
rho      = 1.0e1;
rho_step = 4;
rho_max  = 1.0e8;


t0 = clock;

%%% generate initial Z
%[P,lambda] = MYmexeig(X,0);   
rank_X   = length(find(lambda > 1.0e-8));
rankErr  = abs( sum(lambda) - sum(lambda(1:Rank)) ); 
rankErr0 = rankErr;
Z = mPCA(P,lambda,Rank,e_diag);
%%% test how good is mPCA(X).
infeas = zeros(k,1);
for i=1:k_e
    infeas(i) = e(i) - Z(I_e(i),J_e(i));
end
for i=1:k_l
    infeas(k_e+i) = max( l(i) - Z(I_l(i),J_l(i)), 0 );
end
for i=1:k_u
    infeas(k_e+k_l+i) = max( Z(I_u(i),J_u(i)) - u(i), 0 );
end
normInf = norm(infeas);
if normInf <= tolinf
    X = Z;
    [P,lambda] = MYmexeig(X,0);
    rank_X     = Rank;
    rankErr    = abs( sum(lambda) - sum(lambda(1:Rank)) );
    residue_X  = sum(sum((X-G).*(X-G)))^0.5;
    infoNum.eigendecom = infoNum.eigendecom + 1;
    fprintf('\n Initial RankErr  = %4.3e', rankErr)
    fprintf('\n Initial Residue  = %4.3e', residue_X)
    time_used = etime(clock, t0);
    fprintf('\n Time used to generate the initial point = %.1f',time_used)
    fprintf('\n *** This initial point is exactly CorNewton_mPCA! ***')
    return
end

%%% initial residue and objective function value
residue_X  = sum(sum((X-G).*(X-G)))^0.5;
residue_Z  = sum(sum((Z-G).*(Z-G)))^0.5;
residue_XZ = sum(sum((X-Z).*(X-Z)))^0.5;
fc = 0.5*residue_X^2 + 0.5*residue_Z^2;
fc = fc + 0.5*rho*residue_XZ^2;
%fc_old = fc;

if opt_disp
fprintf('\n\n **************************************************** \n')
fprintf( '      The Iterative Majorization Method Initiated!!!      ')
fprintf('\n ******************************************************* \n')
end

opts.disp     = 0;        
opts.eps_bar  = 1.0e1;
break_level   = 0;
total_AltProj = 0;
for k1 = 1:maxit
     
    if opt_disp
    tt = etime(clock,t0);
    fprintf('\n ================')
    fprintf(' The %2.0dth level of penalty par. %6.5e',k1,rho)
    fprintf('  =========================')
    fprintf('\n ........Calling CaliMat1Mex_Wnorm')
    fprintf('\n CallNo.  NumIt  JacobProd    RankX    RankErr      Sqrt(2*FunVal)     Time')
    fprintf('\n %2.0fth      %s       %s       %3.0d     %3.2e     %9.8e    %.1f',...
        0,'-','-',rank_X,rankErr,sqrt(2)*fc^0.5,tt)
    end
    
    for itersub = 1:maxitsub
        
        C  = (X - G);
        G0 = G + rho*Z - C;
        G0 = G0/(1+rho);
        
        %G0 = G + rho*Z;
        %G0 = G0/(1+rho);
        
        %%% update X: projection onto the linear constraints
%        if itersub==1 
            [X,z,info] = CaliMat1Mex(G0,ConstrA,opts);
%         else   
%             [X,z,info] = CaliMat1Mex(G0,ConstrA,opts,z);             
%         end
        P          = info.P;
        lambda     = info.lam;
        rank_X     = info.rank;
        rankErr    = abs( sum(lambda) - sum(lambda(1:Rank)) ); 
        infoNum.callCN      = infoNum.callCN + 1;
        infoNum.iterCN      = infoNum.iterCN + info.numIter;
        infoNum.JacobProd   = infoNum.JacobProd + info.numJacobProd;       
        infoNum.eigendecom  = infoNum.eigendecom + info.numEig;
               
        residue_X  = sum(sum((X-G).*(X-G)))^0.5;
        residue_XZ = sum(sum((X-Z).*(X-Z)))^0.5;
        fc = 0.5*residue_X^2 + 0.5*residue_Z^2;
        fc = fc + rho*0.5*residue_XZ^2;
        %         relErr = abs(fc_old - fc);
        %         relErr = relErr/max(1, max(fc_old,fc));
        %         fc_old = fc;
        %         if itersub > 1 && relErr <= tolrel
        %             break_level = 1;
        %             if rankErr < tolrank
        %                 break_level = 2;
        %             end
        %             tt = etime(clock,t0);
        %             fprintf('\n %2.0dth     %2.0f      %2.0f       %3.0d     %3.2e   %9.8e    %.1f',...
        %                 itersub, info.numIter, info.numBiCG, rank_X, rankErr, sqrt(2)*fc^0.5, tt)
        %             break;
        %         end
        if rankErr <= rankErr_stop*rankErr0
            break_level = 1;
            tt = etime(clock,t0);
            fprintf('\n %2.0dth     %2.0f      %2.0f       %3.0d     %3.2e   %9.8e    %.1f',...
                itersub, info.numIter, info.numJacobProd, rank_X, rankErr, sqrt(2)*fc^0.5, tt)
            break;
        end
        
        %%% update Z: project onto the rank constraint
        C  = (Z - G); 
        G0 = G + rho*X - C;
        G0 = G0/(1+rho);
        [P,lambda] = MYmexeig(G0,1);
        Z          = Projr(P,lambda,Rank);
        infoNum.eigendecom  = infoNum.eigendecom + 1;
         
        infeas = zeros(k,1);
        for i=1:k_e
            infeas(i) = e(i) - Z(I_e(i),J_e(i));
        end
        for i=1:k_l
            infeas(k_e+i) = max( l(i) - Z(I_l(i),J_l(i)), 0 );
        end
        for i=1:k_u
            infeas(k_e+k_l+i) = max( Z(I_u(i),J_u(i)) - u(i), 0 );
        end
        normInf = norm(infeas);   
        if opt_disp
            if ( itersub <= const.disp1 || mod(itersub,const.disp2) == 0 )
                tt = etime(clock,t0);
                fprintf('\n %2.0dth     %2.0f      %2.0f       %3.0d     %3.2e     %9.8e    %.1f',...
                    itersub, info.numIter, info.numJacobProd, rank_X, rankErr, sqrt(2)*fc^0.5, tt)
                %fprintf('normInf = %6.5e', normInf);
            end
        end
        
        if normInf < tolinf                        
            X          = Z;
            [P,lambda] = MYmexeig(X,0);
            infoNum.eigendecom  = infoNum.eigendecom + 1;
            rank_X     = Rank;
            rankErr    = abs( sum(lambda) - sum(lambda(1:Rank)) );
            residue_X  = sum(sum((X-G).*(X-G)))^0.5;
            break_level = 2;
            break;
        end
         
    end   %end of subproblem
    
    if opt_disp
    tt = etime(clock,t0);
    [hh,mm,ss] = time(tt);
    fprintf('\n   Iter.   PenPar.   Rank(X)    RankError    ||X-G||     Time_used ')
    fprintf('\n   %2.0d     %3.2e    %2.0d      %3.2e      %9.8e     %d:%d:%d \n',...
        k1,rho,rank_X,rankErr,residue_X,hh,mm,ss)
    end
    
    total_AltProj = total_AltProj + itersub;
    if break_level == 1 
        fprintf('\n Alternating terminates at projection onto the linear constraints with small rankErr!')
        break;
    elseif  break_level == 2
        fprintf('\n Alternating terminates at projection onto rank constraints with small normInf!')
        fprintf('\n Norm of infeasibility = %4.3e', normInf)
        break;
    else
        %%% update rho and opts.eps_bar
        rho          = min( rho*rho_step, rho_max );
        opts.eps_bar = max( eps_step*opts.eps_bar, eps_bar_min );
    end
    
end
fprintf('\n Total No. of AltProj = %2.0d', total_AltProj)
fprintf('\n Initial RankErr  = %4.3e', rankErr)
fprintf('\n Initial ||X-G||  = %4.3e', residue_X)
time_used = etime(clock, t0);
fprintf('\n Time used to generate the initial point = %.1f',time_used)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% end of the main program %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%  **************************************
%%  ******** All Sub-routines  ***********
%%  **************************************

%%% To change the format of time 
function [h,m,s] = time(t)
t = round(t); 
h = floor(t/3600);
m = floor(rem(t,3600)/60);
s = rem(rem(t,60),60);
%%% End of time.m



%%% mexeig decomposition
function [P,lambda] = MYmexeig(X,order_abs)
[P,lambda] = mexeig(X);
P          = real(P);
lambda     = real(lambda);
if order_abs == 0
    if issorted(lambda)
        lambda = lambda(end:-1:1);
        P      = P(:,end:-1:1);
    elseif issorted(lambda(end:-1:1))
        return;
    else
        [lambda, Inx] = sort(lambda,'descend');
        P = P(:,Inx);
    end
elseif order_abs == 1
    if issorted(abs(lambda))
        lambda = lambda(end:-1:1);
        P      = P(:,end:-1:1);
    elseif issorted(abs(lambda(end:-1:1)))
        return;
    else
        [lambda1, Inx] = sort(abs(lambda),'descend');
        %     for i=1:length(Inx_neg)
        %          tmp = find(Inx==Inx_neg(i));
        %          lambda1(tmp) = -lambda1(tmp);
        %     end
        lambda = lambda(Inx);
        P = P(:,Inx);
    end
end
return
%%% End of MYmexeig.m




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function X = mPCA(P,lambda,Rank,b)
%lambda>=0 and b>=0
n = length(lambda);
if nargin < 4
    b = ones(n,1);
end

if Rank>0
    P1       = P(:, 1:Rank);
    lambda1  = lambda(1:Rank);
    lambda1  = lambda1.^0.5;
    if Rank>1
        P1 = P1*sparse(diag(lambda1));
    else
        P1 = P1*lambda1;
    end
    pert_Mat = rand(n,Rank);
    for i=1:n
        s = norm(P1(i,:));
        if s<1.0e-12  % PCA breakdowns
            P1(i,:) = pert_Mat(i,:);
            s       = norm(P1(i,:));
        end
        P1(i,:) = P1(i,:)/s;
        P1(i,:) = P1(i,:)*sqrt(b(i));
    end
    X = P1*P1';
else
    X = zeros(n,n);
end
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function X  = Projr(P,lambda,r)
n = length(lambda);
X = zeros(n,n);
if r>0
    P1      = P(:,1:r);
    lambda1 = lambda(1:r);
    if r>1
        lambda1 = lambda1.^0.5;
        P1 = P1*sparse(diag(lambda1));
        X  = P1*P1';
    else
        X = lambda1*P1*P1';
    end
end
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function X  = Projr(P,lambda,r)
% n = length(lambda);
% X = zeros(n,n);
% if r>0
%     P1      = P(:,1:r);
%     lambda1 = lambda(1:r);
%     for i=1:r
%         P1(:,i) = lambda1(i)*P1(:,i);
%     end
%     X = P(:,1:r)*P1';
% end
% return
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%









