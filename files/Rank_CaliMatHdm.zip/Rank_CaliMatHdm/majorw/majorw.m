function [Xn, Fn, residue_1, time] = majorw_test( R, d, WW, ftol,  ftest, gradtol, tolrel )
%%%%%
%  MAJOR Majorisation algorithm for rank reduction of correlation matrices
%  Majorization algorithm for minimization of F(X)=\sum_{i<j}w_{ij}(r_{ij}-<x_i,x_j>)^2 such that diag(X*X')=I with X an nxd matrix with n=size(R,1)=size(R,2).
%  Convergence is guaranteed if the matrix R has unit diagonal and if all elements of W are positive.
%  gradtol is the convergence criterion for the norm of the gradient 4*Psi*X with Psi = X*X'-R.
%  ftol is the convergence criterion for the improvement in the function
%  value F. Both criteria should be satisfied for convergence.
%  usage [Xn, Fn] = majorw( R, d, W, ftol, gradtol )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Last modified on November 23, 2009;  10:00AM

t0 = clock;


residue_cutoff = 10;
if tolrel <= 1.0e-4;
    residue_cutoff = 100;
end
     
const1_disp = 10;
const2_disp = 10;
eigdecomp_time = 0;
disp_level = 1;


const_hist = 20000;
hist_residue = zeros(const_hist,1);
n_base = 10;

%%% dimension
N = size(R,1);

%%% first obtain initial guess
% X = guess(R,d);
X = guess_new(R,d);    %% mPCA; added on Oct.6, 2009.


WeightFlag = any(any(1-WW));  %% =1 nonequal weight on Oct.6, 2009.

if WeightFlag
    W = WW.^2;   %%% on Nov 3, 2009
else
    W = WW;
end

%%% sum of weights
if WeightFlag
    sumW = 0.0;
    for i=1:N
        for j=(i+1):N
            sumW = sumW + W(i,j);
        end
    end
else
    sumW = N*(N-1)/2;
end

% initial gradient, obj value
mygrad   = P_tangent( X, dFw( X, R, W, sumW ) );
normgrad = norm(mygrad,'fro');
Fn = Fw(X,R,W,sumW);
%Fold = Fn*(1.0 + ftol) + 1.0; % at first iteration no Fold is known, this choice guarantees that convergence is not obtained at the first iteration
residue_1 = sqrt(8*sumW*Fn);
hist_residue(1) =  residue_1;

% output
iter = 0;
time = etime(clock,t0);
fprintf('\n')
disp(sprintf('%s\t%s\t\t%s\t\t\t%s\t%s','iter','|grad|','F(X)','Time','maximum_eig_time'));
disp(sprintf('%d\t%3.2e\t%9.8e\t\t%.1f\t\t%.1f',iter,normgrad,sqrt(8*sumW*Fn),time,eigdecomp_time));


% useful in later calculations
if WeightFlag
    W_bar = WW;   % W_bar = W.^0.5;    
    WR    = W.*R;
else
    WR = R;
end

%while ( normgrad>gradtol) || ( Fold/Fn - 1.0 > ftol )
% while (  normgrad > gradtol &&  ( sqrt(8*sumW*Fn) - ftest )/max(1,ftest) > ftol )   
 while ( normgrad > gradtol )
     
     
    for i=1:N

        % calculate B and its largest eigenvalue lambda
        %             B = zeros(d);
        %             for j=1:(i-1)
        %                 B = B + W(i,j)*(X(j,:)'*X(j,:));
        %             end
        %             for j = (i+1):N
        %                 B = B + W(i,j)*(X(j,:)'*X(j,:));
        %             end
        %
        %%% on oct 6, 2009.
        X_bar = X;
        % B = zeros(d);
        if WeightFlag  % nonequal weight
            for j = 1:N
                X_bar(j,:) = W_bar(i,j) * X(j,:);  %% X_bar = (W.^0.5)(i,:)*X
            end
        end
        B = X_bar'*X_bar - X_bar(i,:)'*X_bar(i,:);


        % lambda = max(eig(B));
        tt = clock;
        if d <= 125       %% on Oct.6,2009.
            lambda = max(eig(B));
        else
            OPTS.disp = 0;
            lambda = eigs(B,1,'LA',OPTS);
        end
        eigdecomp_time  = eigdecomp_time  + etime(clock,tt);

        % calculate the position at which the minimum of the
        % majorization function is obtained
        z = (lambda - WR(i,i))*X(i,:) - (B*X(i,:)')'+ WR(i,:)*X;
        X(i,:) = z/norm(z);

    end

    % gradient, obj value
    iter = iter + 1;
    mygrad = P_tangent( X, dFw( X, R, W, sumW ) );
    normgrad = norm(mygrad,'fro');
    Fold = Fn;
    
    Fn = Fw(X,R,W,sumW);    
    residue_1 = sqrt(8*sumW*Fn);
    hist_residue(iter+1) = residue_1;

    % output
    if ( iter <= const1_disp || mod(iter,const2_disp) == 0 )
        disp_level = 1;
        time = etime(clock,t0);
        disp(sprintf('%d\t%3.2e\t%9.8e\t\t%.1f\t\t%.1f',iter,normgrad,sqrt(8*sumW*Fn),time,eigdecomp_time));        
    else
        disp_level = 0;
    end

    %%% termination test
    if  iter >= n_base-1
            relErr = abs( hist_residue(iter+2-n_base) - hist_residue(iter+1))...
                / max( residue_cutoff , max(hist_residue(iter+1), hist_residue(iter+2-n_base)));
        if relErr <= tolrel
            if disp_level == 0
                disp(sprintf('%d\t%3.2e\t%9.8e\t\t%.1f\t\t%.1f',iter,normgrad,sqrt(8*sumW*Fn),time,eigdecomp_time));
                disp_level = 1;
            end
            fprintf('relative error = %8.7e \n',relErr)
            break;
        end
    end

end

Xn = X;

if disp_level == 0
    time  = etime(clock,t0);
    disp(sprintf('%d\t%3.2e\t%9.8e\t\t%.1f\t\t%.1f',iter,normgrad,sqrt(8*sumW*Fn),time,eigdecomp_time));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% end of the main program %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%  **************************************
%%  ******** All Sub-routines  ***********
%%  **************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Delta = P_tangent( Y, X )
% Delta = P_tangent( Y, X )
% projects X onto the tangent space at Y thereby producing Delta
% The manifold here is { Y nxd real matrix, norm(Y(i,:))=1 i=1:n } (n products of the d-1 sphere)

Delta = X - diag( diag( X * Y' ) ) * Y;
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ f ] = Fw( X, R, W, sumW )
%F F(X)=\sum_{i<j}w_{ij}(r_{ij}-<x_i,x_j>)^2
%  F(X)=\sum_{i<j}w_{ij}(r_{ij}-<x_i,x_j>)^2

XXT = X*X';
n = size(R,1);
f = 0.0;
for i=1:n
    for j=(i+1):n
        diff = R(i,j)- XXT(i,j);
        f    = f + W(i,j)*diff^2;
    end
end
f = f/(4.0*sumW);

return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result = dFw( X, R, W, sumW )
% result = dFw( X, R, W )
% the differential of Fw

[n,d] = size(X);
result = zeros(n,d);
XXT = X*X';
for k=1:n
    for l=1:d
        for j=1:(k-1)
            result(k,l) = result(k,l) + W(k,j)*( R(k,j) - XXT(k,j) )*X(j,l);
        end
        for j=(k+1):n
            result(k,l) = result(k,l) + W(k,j)*( R(k,j) - XXT(k,j) )*X(j,l);
        end
    end
end
result = -2.0 * result;
% result = -2.0 * result / (4.0 * sumW);
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%% mexeig decomposition
function [P,lambda] = MYmexeig(X)
[P,lambda] = mexeig(X);
P          = real(P);
lambda     = real(lambda);
if issorted(lambda)
    lambda = lambda(end:-1:1);
    P      = P(:,end:-1:1);
elseif issorted(lambda(end:-1:1))
    return;
else
    [lambda, Inx] = sort(lambda,'descend');
    P = P(:,Inx);
end
% % % Rearrange lambda and P in the nonincreasing order
% % if lambda(1) < lambda(end) 
% %     lambda = lambda(end:-1:1);
% %     P      = P(:,end:-1:1);
% % end
return
%%% End of MYmexeig.m




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function X = guess_new(R,Rank)
% Principal components analysis. 
% Given an n x n matrix R with > Rank nonnegative eigenvalues 
% find an n x d matrix X such that X*X' is approximately equal to R.
n = length(R);
X = zeros(n,Rank);
[P, lambda] = MYmexeig(R);    
lambda = max(0, lambda);
if Rank>0
    P1       = P(:,1:Rank);
    lambda1  = lambda(1:Rank);
    lambda1  = lambda1.^0.5;
    if Rank>1
        P1 = P1*sparse(diag(lambda1));
    else
        P1 = P1*lambda1;
    end
    pert_Mat = rand(n,Rank);
    for i=1:n
        s = norm(P1(i,:));
        if s<1.0e-12  % PCA breakdowns
            disp('PCA may breakdown')
            P1(i,:) = pert_Mat(i,:);
            s       = norm(P1(i,:));
        end
        P1(i,:) = P1(i,:)/s;
    end
   X = P1;
end
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


