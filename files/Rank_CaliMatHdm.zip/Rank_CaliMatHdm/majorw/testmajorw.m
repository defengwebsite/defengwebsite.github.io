clear all




n = 300;
%%
%%-----------------------------------------
%%% Generate matrix G
%%-----------------------------------------
%%
LongCorr = 0.5; 
beta     = -0.05;
G = zeros(n,n);
for i = 1:n
    for j = 1:i        
        G(i,j) = LongCorr + (1-LongCorr)*exp(beta*abs(i-j));        
    end
end
G = G + G' - diag(diag(G));


%%% The rank constraint
r_rank = 20;



%%
%%-----------------------------------------
%%% Generate weight matrix H
%%-----------------------------------------
%%
H0 = sprand(n,n,0.5);
H0 = triu(H0) + triu(H0,1)'; % W0 is likely to have small numbers
H0 = (H0 + H0')/2;
H0 = 0.01*ones(n,n) + 99.99*H0; %%% H0 is in [0.01, 100]
H1 = rand(n,n);
H1 = triu(H1) + triu(H1,1)'; % W1 is likely to have small numbers
H1 = (H1 + H1')/2;
H  = 0.1*ones(n,n) + 9.9*H1; %%% H is in [.1,10]
%%%%%%%%%%%%%%%%%%%%% Assign weights H0  on partial elemens
s = sprand(n,1,min(10/n,1));
I = find(s>0);
d = sprand(n,1,min(10/n,1));
J = find(d>0);
if length(I)>0 && length(J)>0
    H(I,J) = H0(I,J);
    H(J,I) = H0(J,I);
end
H = (H + H')/2;
%%% scale H
Hscale = sum(sum(H))/n^2;
H      = H/Hscale;
 
Hmin = min(min(H))
Hmax = max(max(H))






 
 
gradtol   = 1.0e-5;  
ftest     = 0;
ftol_test = 1.0e-6;
tolrel    = 1.0e-5; 
% fprintf('\n---------- Call Major weight ---------------')
[Xn, Fn] = majorw_original( G, r_rank, H, ftol_test, ftest, gradtol, tolrel );

 
[Xn, Fn, residue_final, ttime] = majorw( G, r_rank, H, ftol_test, ftest, gradtol, tolrel );
 



 



