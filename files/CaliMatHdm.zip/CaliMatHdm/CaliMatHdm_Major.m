function [X,INFOS] = CaliMatHdm_Major(G,H,ConstrA,OPTIONS)
%%%%%%%%%%%%% This code is designed to solve %%%%%%%%%%%%%%%%%%%%%
%%       min   0.5*|| H o (X-G) ||^2
%%       s.t.  X_ii   = e_ij    (i,j) in (I_e,J_e)
%%             X_ij  >= l_ij    (i,j) in (I_l,J_l)
%%             X_ij  <= u_ij    (i,j) in (I_u,J_u)
%%              X    >= tau*I    X is SDP (tau>=0 and may be zero)
%%%
%   Parameters:
%   Input
%   G:            the given symmetric correlation matrix
%   H:            the weight matrix for G
%   ConstrA:      the equality and inequality constraints
%   Rank:         the rank constraint to X
%   OPTIONS: 
%
%   Output
%   X         the optimal primal solution
%   INFOS     the final information
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Last modified on March 31, 2010.


%%
%%-----------------------------------------
%%% get constraints infos from constrA
%%-----------------------------------------
%%
e   = ConstrA.e; I_e = ConstrA.Ie; J_e = ConstrA.Je;
l   = ConstrA.l; I_l = ConstrA.Il; J_l = ConstrA.Jl;
u   = ConstrA.u; I_u = ConstrA.Iu; J_u = ConstrA.Ju;
k_e = length(e); k_l = length(l);  k_u = length(u);
k   = k_e + k_l + k_u;  n = length(G);

tau        = 0;
maxit      = 500; 
tolrel     = 1.0e-5;   % default
scale_data = 0;        % scaling data
%%                                      
%%-----------------------------------------
%% get parameters from the OPTIONS structure. 
%%-----------------------------------------
%%
if exist('OPTIONS')
    if isfield(OPTIONS,'tau');              tau           = OPTIONS.tau; end
    if isfield(OPTIONS,'maxit');            maxit         = OPTIONS.maxit; end
    if isfield(OPTIONS,'tolrel');           tolrel        = OPTIONS.tolrel; end
    if isfield(OPTIONS,'scale_data');       scale_data    = OPTIONS.scale_data; end
end
tolKKT = 1.0e-5;    
residue_cutoff = 10 ;
if tolrel <= 1.0e-5;
   residue_cutoff = 100 ;
end
%%% constant pars
const.disp1 = 10;
const.disp2 = 10;
const.residue_hist = 2;  %10; 4;  const.residue_hist = max(2, const.residue_hist); 
runhist.residue    = zeros(const.residue_hist,1);
%progress_residue  = 1.0e-4
%progress_relErr   = 0.001*tolrel;
Totalcall_CaliMatW   = 0;
Totaliter_CaliMatW   = 0;
Totalnumb_BiCG       = 0;
Totalnumb_eigendecom = 0;


t0 = clock;

%%% reset input pars
eye_n  = speye(n);
G      = G - tau*eye_n;     
G      = (G + G')/2;        
Idx    = find(I_e==J_e);
e(Idx) = e(Idx) - tau;     % reset the diagonal part of e
ConstrA.e = e;
%%% scale H
H = (H + H')/2;    % make sure that H is symmetric
if ( scale_data )
    Hscale = sum(sum(H))/n^2;
    H      = H/Hscale;
end
H2H = H.*H;
%H_max  = max(max(H));
%H_max2 = H_max^2;   

weightFlag = any(any(H-ones(n)));  % =0 if equal weights
if weightFlag == 0
    msg = sprintf('Equal weight case: call CaliMat1Mex.m');
    fprintf('\n %s ', msg);
    [X,INFOS] = CaliMat1Mex(G,ConstrA);
    return;
end

w_scalar = 1.4;  %% to control the overestimation about w
d     = diag(H);
w_est = max(H,[],2);
%% note that d<=w_est should be guaranteed
w_diff = max(0,w_est-d) + 1.0e-6; % e-6 to avoid numerical instability
Delta  = max(0, H2H - d*d');
DW = d*w_diff' + w_diff*d';
DD = -DW + ( DW.^2 + 4*(Delta.*(w_diff*w_diff')) ).^(1/2);
DD = 0.5*(DD./(w_diff*w_diff'));
alpha = max(max(DD));
fprintf('alpha = %d',alpha)
%%%%% alpha is chosen such that [d+alpha*(w-d)_+]*[d+alpha*(w-d)_+]^T >= H2H
w_est  = d + alpha*(w_diff - 1.0e-6);
if alpha < 0.1
    w_scalar =1.0;
end
w      = w_est/w_scalar;
Ind    = find(w==0);
w(Ind) = 1;
W     = diag(w);
w_inv = w.^(-1);


fprintf('\n ******************************************')
fprintf('\n  The problem information: \n')
fprintf(' Dim.  of sdp  constr.    = %3.0f \n',n)
fprintf(' Num. of fixed elements   = %3.0f \n',k_e)
fprintf(' Num. of lower bound      = %3.0f \n',k_l)
fprintf(' Num. of upper bound      = %3.0f \n',k_u)
%%
%%---------------------------------------------------------------
%%% Calling CaliMat1Mex_Wnorm to generate an initial point
%%---------------------------------------------------------------
%%
fprintf('\n ^^^^^^^^ Preprocessing by CaliMat3Mex_Wnorm ^^^^^^^^ ')
optsInt.disp         = 0;
optsInt.finalEig     = 0;
optsInt.use_ProjGrad = 0;
optsInt.eps_bar      = 1.0e1;
W_pre = speye(n,n);  %% no Hnorm for initialization
[X,z,infoInt] = CaliMat1Mex_Wnorm(G,W_pre,ConstrA,optsInt);
Totalcall_CaliMatW   = Totalcall_CaliMatW + 1;
Totaliter_CaliMatW   = Totaliter_CaliMatW + infoInt.numIter;
Totalnumb_BiCG       = Totalnumb_BiCG + infoInt.numBiCG;
Totalnumb_eigendecom = Totalnumb_eigendecom + infoInt.numEig;
objM             = H.*(X-G);
residue_CaliMatW = sum(sum(objM.*objM))^0.5;
%%% check KKT condition
KKT = H2H - W_pre.*W_pre;   %%% [X,z] solves CaliMat1Mex_Wnorm(G,W_pre,ConstrA,optsInt)
KKT = KKT.*(X-G);
Err_KKT = sum(sum(KKT.*KKT))^0.5;
Err_KKT = Err_KKT/max(w)^2;
if ( Err_KKT <= tolKKT )
    fprintf('\n The initial calibration is good enough!')
    fprintf('\n The KKT error     = %4.3e', Err_KKT)
    fprintf('\n Residue_CaliMatW  = %9.8e', residue_CaliMatW)
    time_used = etime(clock,t0);
    fprintf('\n Total computing time   = %.1f(secs) \n', time_used);
    INFOS.iter    = 0;
    INFOS.callCN  = Totalcall_CaliMatW;
    INFOS.itCN    = Totaliter_CaliMatW;
    INFOS.itBiCG  = Totalnumb_BiCG;
    INFOS.numEig  = Totalnumb_eigendecom;
    INFOS.residue = residue_CaliMatW;
    INFOS.time    = time_used;
    return;
end 
residue_1    = residue_CaliMatW;
residue_1old = residue_1;
 

fprintf('\n\n ***************************************** \n')
fprintf( '      The Majorization Method Initiated!!!      ')
fprintf('\n ******************************************* \n')
fprintf('\n ........Calling CaliMat1Mex_Wnorm')
tt         = etime(clock,t0);
[hh,mm,ss] = time(tt);
fprintf('\n CallNo.  NumIter   NumBiCGs    ||Ho(X-G)||       RelErr     Time_used')
fprintf('\n %2.0fth       %d         %d      %9.8e        %s         %d:%d:%d',0,infoInt.numIter,infoInt.numBiCG,residue_1,'-',hh,mm,ss)
  
iter = 1;
opts.disp         = 0;
opts.finalEig     = 0;
opts.use_ProjGrad = 0;
opts.eps_bar      = 1.0e1;
eps_bar_min       = 1.0e-8;
for iter = 1:maxit

    C = H2H.*(X - G);
    for i=1:n
        C(i,:) = w_inv(i)*C(i,:);
    end
    for j=1:n
        C(:,j) = C(:,j)*w_inv(j);
    end
    G0  = X - C;
       
    [X,z,info] = CaliMat1Mex_Wnorm(G0,W,ConstrA,opts,z);
    Totalcall_CaliMatW   = Totalcall_CaliMatW + 1;
    Totaliter_CaliMatW   = Totaliter_CaliMatW + info.numIter;
    Totalnumb_BiCG       = Totalnumb_BiCG + info.numBiCG;
    Totalnumb_eigendecom = Totalnumb_eigendecom + info.numEig;
    objM      = H.*(X-G);
    residue_1 = sum(sum(objM.*objM));
    residue_1 = residue_1^0.5;

    %%% residue history
    if iter <= const.residue_hist
        runhist.residue(iter) = residue_1;
    else
        for j = 1:const.residue_hist-1
            runhist.residue(j) = runhist.residue(j+1);
        end
        runhist.residue(const.residue_hist) = residue_1;
    end
    %%% relErr history
    if iter >= const.residue_hist
        relErr = abs(runhist.residue(1) - runhist.residue(const.residue_hist));
        relErr = relErr/max(residue_cutoff, max(runhist.residue(1), runhist.residue(const.residue_hist)));
    else
        relErr = abs(runhist.residue(1) - runhist.residue(iter));
        relErr = relErr/max(residue_cutoff, max(runhist.residue(1), runhist.residue(iter)));
    end 
    %%% termination test
    if ( relErr <= tolrel && iter > 1 )
        fprintf('\n Residue reductions satisfies the stopping condition !')
        tt         = etime(clock,t0);
        [hh,mm,ss] = time(tt);
        fprintf('\n %2.0dth      %2.0f         %2.0f      %9.8e    %5.4e   %d:%d:%d',...
            iter, info.numIter, info.numBiCG, residue_1, relErr, hh,mm,ss)
        break;
    end
    if ( iter <= const.disp1 || mod(iter,const.disp2) == 0 )
        tt         = etime(clock,t0);
        [hh,mm,ss] = time(tt);
        fprintf('\n %2.0dth      %2.0f         %2.0f      %9.8e    %5.4e   %d:%d:%d',...
            iter, info.numIter, info.numBiCG, residue_1, relErr, hh,mm,ss)
    end
    %%% check if w_scalar leads to an increase in residue
    if residue_1 > residue_1old
        w_scalar = w_scalar/1.1;
        w_scalar = max(1,w_scalar);
        if w_scalar > 1
            w     = w_est/w_scalar;
            w_min = min(w);
            w_max = max(w);
            if (w_max-w_min)/w_max <= 0.25
                w = w_max*ones(n,1);
            end
            Ind    = find(w==0);
            w(Ind) = 1;
            W     = diag(w);
            w_inv = w.^(-1);
        end
    end
    residue_1old = residue_1;

    %%% update eps_bar for next call of CaliMat1Mex_Wnorm
    if iter <= const.residue_hist
        opts.eps_bar = opts.eps_bar/(10^iter);
        opts.eps_bar = max( opts.eps_bar, eps_bar_min);
    else
        opts.eps_bar = min(opts.eps_bar, min(1,relErr)^2);
        opts.eps_bar = max( opts.eps_bar, eps_bar_min);
    end

end   %end of subproblem

%%% check KKT condition
%%%   This can only be used when X does not decrease any more
KKT = H2H.*(X-G);
KKT = KKT - (w*w').*(X-G0); %% we only need to consider the first KKT equation
Err_KKT = sum(sum(KKT.*KKT))^0.5; % norm(KKT,'inf'); %
C = H2H.*G;
norm_C = sum(sum(C.*C))^0.5;
Err_KKT = Err_KKT/(1+ norm_C);

time_used     = etime(clock,t0);
INFOS.iter    = iter;
INFOS.callCN  = Totalcall_CaliMatW;
INFOS.itCN    = Totaliter_CaliMatW;
INFOS.itBiCG  = Totalnumb_BiCG;
INFOS.numEig  = Totalnumb_eigendecom;
INFOS.relErr  = relErr;
INFOS.residue = residue_1;
INFOS.Err_KKT = Err_KKT;
INFOS.time    = time_used;

fprintf('\n **************** Final Information ******************** \n');
fprintf('\n  The problem information: \n');
fprintf(' Dim.  of    sdp        constr  = %d \n',n);
fprintf(' Num. of fixed elements         = %d \n',k_e);
fprintf(' Num. of lower bound            = %d \n',k_l);
fprintf(' Num. of upper bound            = %d \n',k_u);
fprintf(' ------------------------------------------------------- \n');
fprintf(' Num of calling CN        = %d \n', INFOS.callCN);
fprintf(' Total num of BiCG        = %d \n', INFOS.itBiCG);
fprintf(' Total num of eigendecom  = %d \n', INFOS.numEig);
fprintf(' The relErr               === %5.4e \n', INFOS.relErr);
fprintf(' Final ||Ho(X-G)||        ===== %9.8e \n', INFOS.residue);
fprintf(' Primal function value    ===== %9.8e \n', 0.5*INFOS.residue^2);
 fprintf(' RelativeKKT error       ===== %9.8e \n', INFOS.Err_KKT);
fprintf(' Computing time           ======= %.1f(secs) \n', INFOS.time);
fprintf(' ********************************************************* \n');
%fclose(fid);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% end of the main program %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%  **************************************
%%  ******** All Sub-routines  ***********
%%  **************************************

%%% To change the format of time 
function [h,m,s] = time(t)
t = round(t); 
h = floor(t/3600);
m = floor(rem(t,3600)/60);
s = rem(rem(t,60),60);
%%% End of time.m



% %%% mexeig decomposition
% function [P,lambda] = MYmexeig(X)
% [P,lambda] = mexeig(X);
% P          = real(P);
% lambda     = real(lambda);
% if issorted(lambda)
%     lambda = lambda(end:-1:1);
%     P      = P(:,end:-1:1);
% elseif issorted(lambda(end:-1:1))
%     return;
% else
%     [lambda, Inx] = sort(lambda,'descend');
%     P = P(:,Inx);
% end
% return
% %%% End of MYmexeig.m







