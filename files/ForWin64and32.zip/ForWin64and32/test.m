
clear all
% load WindFarmG.mat;
% G_orig = targetCorr;
% nn = length(G_orig);
% n = 2000;
% 
% G = G_orig(1:n,1:n);

% rand('state',0);
% 
% load GeneG.mat;
% 
% 
% n = length(G);

n = 2000;
%G = G(1:n,1:n);

G =rand(n,n);

G = (G + G')/2;
%xx = 10.^(4*[-1:1/(n-1):0]);
%G = gallery('randcorr',n*xx/sum(xx));


alpha = 0.00;
E = randn(n); E = triu(E) + triu(E,1)';
G = (1-alpha)*G + alpha*E;
G = min(1.0, max(G,-1.0));
 
% for i=1:n; G(i,i)=1.0; end

 G = rand(n,n);
 G =  (G  +  G')/2;
 
%   G =2.0*rand(n,n)-ones(n,n); %Case I
%   G = (G+G')/2;

%  G = 2*randn(n,n);
%   G = triu(G) + triu(G,1)';
% G = (G+G')/2;

% 
%    G = 10*rand(n,n);
% % % 
%     G = (G + G');
 G = G - diag(diag(G)) + eye(n);
 
  b = ones(n,1);
  
  b_original = ones(n,1);

  v = ones(n,1) ; %rand(n,1); for testing diagonal weighted case
  
  v = v.^-0.5;

 
  G = diag(v)*G*diag(v);
%   b =  v.^2; 
%  b = rand(n,1);
%   b = max(b, 1.0e-4);
   b_original = b;

 b = v.^2;
 
 [X,y] = CorNewton2Mex(G,b,0,1.0e-12);
% % [X,y] = CorNewton2Mex1(G,b,0);
% % [X,y] = CorNewton2Mex_Jan6_09(G,b,0);
% 
X = diag(v.^-1)*X*diag(v.^-1);
  

  b_est = diag(X);
  b_estmax = max(b_est)
  b_estmin = min(b_est)
  b_error = norm(b_est-b_original,'inf')
  
  return
    
