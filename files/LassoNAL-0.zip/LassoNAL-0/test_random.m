%%*********************************************************************
%%*********************************************************************
clear all;
rng('default');
addpath(genpath(pwd));
 
%% Input data: A b lambda 
 
 m = 50;
 n = 50000;
 A = randn(m,n);
 k = 0.1*n;
 xx = zeros(n,1);
 xstar = 1.2*sqrt(2*log(n));
 xx(1:k) = xstar;
 %err = 0.001*randn(m,1);
 b = A*xx;%+err;
 
 Amap  = @(x) A*x;
 ATmap = @(x) A'*x; 
    
%% tuning parameters   

lambdamax=norm(ATmap(b),'inf');
eigsopt.issym = 1;
Rmap=@(x) A*x;
Rtmap=@(x) A'*x;
RRtmap=@(x) Rmap(Rtmap(x));
Lip = eigs(RRtmap,length(b),1,'LA',eigsopt);

fprintf('\n-----------------------------------------------');
fprintf('------------------------------')
fprintf('\n Problem: n = %g,  m = %g    lambda(max) = %g ',n,m, lambdamax)
fprintf('\n Lip = %3.2e', Lip);
fprintf('\n-----------------------------------------------');
fprintf('------------------------------')

stoptol = 1e-6;%stopping tol

for crho = 1e-3; 
   lambda=crho*lambdamax;
   if (true)
      nalop.stoptol = stoptol;
      nalop.Lip = Lip; %can be set to 1
      Ainput.A = A;
      Ainput.Amap = @(x) Amap(x);
      Ainput.ATmap = @(x) ATmap(x);
      %% initial point
%       xold = zeros(n,1);
%       yold = zeros(n,1);
%       xiold= zeros(m,1);
%       [obj,y,xi,x,info,runhist] = Ssnal_L1S(Ainput,b,n,lambda,nalop,yold,xiold,xold);
      %% if no initial point available
      [obj,y,xi,x,info,runhist] = SSNAL_Classic_Lasso(Ainput,b,n,lambda,nalop);
   end
end
%%*********************************************************************
