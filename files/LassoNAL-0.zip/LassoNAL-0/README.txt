Welcome to LassoNAL! 

A MATALB software package for solving Lasso regularized least squares problems based on
a semismooth Newton augmented Lagrangian method.
Authors: Xudong Li, Defeng Sun, and Kim-Chuan Toh. 

The algorithm in based on the paper 
[A highly efficient semismooth Newton augmented Lagrangian method for solving Lasso problems,
SIAM J. Optimization (2017), XXX--XXX.]


Firstly, unpack the software.


Run Matlab in the directory LassoNAL
In the Matlab command window, type: 
>> startup 
By now, LassoNAL is ready for you to use.

=========================================================================================================================


In the package, three run files are provided for the demonstration purpose.

test_random: for LASSO problems with randomly generated data 

test_sparco: for LASSO problems with sparco data 

test_UCI: for LASSO problems with UCI data 
(Note that the UCI dataset is not included in the package. To generate the UCI dataset, 
download the original datasets tested in above paper from UCI data repository 
and put them into the folder [\Util\genUCIdatafun\UCIdataorg]. 
Then, run genUCIdata.m. For demonstration purpose, 
''bodyfat_scale'' is left in the folder [\Util\genUCIdatafun\UCIdataorg].)

===========================================================================================================================



